<?php
$host = 'localhost';
$usuario = 'u427706089_ps';
$clave = 'Jry73Ngf75';
$base = 'u427706089_ps';
$conn = mysqli_connect($host, $usuario, $clave, $base) or die('Error BD');
mysqli_set_charset($conn, 'utf8');
?>