<?php
include("../config.php");

ini_set('display_errors', 1);
error_reporting(E_ALL);

//require_once '../conectar.php';
session_start();

// Banners para carrusel
$banners = mysqli_query($conn, "
  SELECT g.idcodgusto, p.produ, i.rutaimg
  FROM gustos g
  JOIN producto p ON p.idprodu=g.idprodu
  JOIN imagen i ON i.idimagen=g.idimagen
  WHERE p.enweb=1
  LIMIT 5
");

// Promociones
$promos = mysqli_query($conn, "
  SELECT idprodu, produ, observ, precio, imagen
  FROM producto
  WHERE enweb=1 AND enpromocion=1
  LIMIT 6
");
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Perfushopping.ar</title>
  <link rel="stylesheet" href="assets/css/style.css">
  <link rel="icon" href="assets/img/favicon.png">
</head>
<body>

  <!-- HEADER -->
  <header class="site-header">
    <div class="logo">
      <a href="index.php"><img src="assets/img/logo.png" alt="Perfushopping"></a>
    </div>
    <nav class="nav-menu">
      <a href="#catalogo">Catálogo</a>
      <a href="register.php">Registrarse</a>
      <a href="login.php">Ingresar</a>
      <a href="#" id="cart-toggle">Carrito</a>
    </nav>
    <div class="search-bar">
      <form action="catalogo.php" method="get">
        <input type="text" name="q" placeholder="Buscar fragancias…">
        <button type="submit">🔍</button>
      </form>
    </div>
  </header>

  <!-- CARRUSEL DE BANNERS -->
  <section class="carousel">
    <div class="swiper-container">
      <div class="swiper-wrapper">
        <?php while($b = mysqli_fetch_assoc($banners)): ?>
        <div class="swiper-slide">
          <img src="assets/img/<?php echo $b['rutaimg']; ?>.jpg" alt="<?php echo htmlspecialchars($b['produ']); ?>">
          <div class="slide-caption">
            <h3><?php echo htmlspecialchars($b['produ']); ?></h3>
            <a href="catalogo.php?cat=<?php echo $b['idcodgusto']; ?>" class="btn-primary">Ver variedad</a>
          </div>
        </div>
        <?php endwhile; ?>
      </div>
      <div class="swiper-button-prev"></div>
      <div class="swiper-button-next"></div>
    </div>
  </section>

  <!-- PROMOCIONES -->
  <section id="catalogo" class="product-grid">
    <h2>Promociones</h2>
    <div class="grid">
      <?php while($p = mysqli_fetch_assoc($promos)): ?>
      <div class="card">
        <img src="assets/img/<?php echo $p['imagen']; ?>.jpg" alt="<?php echo htmlspecialchars($p['produ']); ?>">
        <h3><?php echo htmlspecialchars($p['produ']); ?></h3>
        <p class="desc"><?php echo htmlspecialchars($p['observ']); ?></p>
        <p class="price">$<?php echo number_format($p['precio'],2,',','.'); ?></p>
        <button class="btn-add" data-id="<?php echo $p['idprodu']; ?>">Agregar al carrito</button>
      </div>
      <?php endwhile; ?>
    </div>
  </section>

  <!-- CARRITO SLIDE-IN -->
  <aside id="cart-drawer">
    <h2>Tu carrito</h2>
    <div id="cart-items"></div>
    <p class="total">Total: $<span id="cart-total">0</span></p>
    <a href="checkout.php" class="btn-primary full">Pagar ahora</a>
  </aside>

  <!-- FOOTER -->
  <footer class="site-footer">
    <p>© Perfushopping • Reconquista, Santa Fe</p>
    <p>Envíos con Correo Argentino • Pagos con MercadoPago y NAVE</p>
    <div class="social-links">
      <a href="https://instagram.com/perfushopping">Instagram</a>
      <a href="https://wa.me/543482706999">WhatsApp</a>
    </div>
  </footer>

  <script src="assets/js/whatsapp.js"></script>
  <script src="assets/js/cart.js"></script>
  <script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>
  <script src="assets/js/carousel.js"></script>
</body>
</html>
