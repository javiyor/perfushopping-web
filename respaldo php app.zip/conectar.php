<?php
$host = "localhost";
$usuario = "u427706089_ps";
$clave = "Jry73Ngf75";
$base_datos = "u427706089_ps";

$conn = mysqli_connect($host, $usuario, $clave, $base_datos);

if (!$conn) {
    die("Error de conexi�n: " . mysqli_connect_error());
}
?>

