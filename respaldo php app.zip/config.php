<?php
	$host = "perfushopping2018.sytes.net";        // O el nombre del servidor MySQL
	$user = "perfus";       // Tu usuario MySQL
	$pass = "Perfu2018_";    // Tu contraseña MySQL
	$db   = "perfushopping";        // Nombre de tu base de datos

	$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>